This software is the copyright of The Lerryn Consultancy Ltd and
may not be copied, duplicated or modified other than as permitted
in the licence agreement.

      � 2009 - 2012  Lerryn Data Technology Ltd
                     Lerryn House
                     Warren Road
                     Cheadle Hulme
                     Cheshire
                     SK8 5AA

Tel 0161 486 2803   Fax 0161 486 2801
Email Support@lerryn.com

Lerryn is a Registered Trademark of the Lerryn Group Ltd
eShopCONNECT is a Trademark of Lerryn Data Technology Ltd
-------------------------------------------------------------------

Lerryn API extension for Magento.
v1.04
