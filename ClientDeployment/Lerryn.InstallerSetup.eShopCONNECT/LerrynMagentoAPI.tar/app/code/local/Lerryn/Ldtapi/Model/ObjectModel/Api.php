<?php
//
// eShopCONNECT - Magento API
// Module: Api.php
//
// This software is the copyright of Lerryn Data Technology Ltd and
// may not be copied, duplicated or modified other than as permitted
// in the licence agreement.
//
//       � 2009 - 2012  Lerryn Data Technology Ltd
//                      Lerryn House
//                      Warren Road
//                      Cheadle Hulme
//                      Cheshire
//                      SK8 5AA
//
// Tel 0161 486 2803   Fax 0161 486 2801
// Email Support@lerryn.com
//
// Lerryn is a Registered Trademark of the Lerryn Group Ltd
// eShopCONNECT is a Trademark of Lerryn Data Technology Ltd
// -------------------------------------------------------------------
class Lerryn_Ldtapi_Model_ObjectModel_api extends Mage_Api_Model_Resource_Abstract
{
	/*
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '
        '   Description -   ldtGetStoreInfo() -   Returns information about a Magento store
        '
        ' Amendment Log
        '------------------------------------------------------------------------------------------
        ' Date     | Name            | Vers.     | Description
        '------------------------------------------------------------------------------------------
        ' 05/05/11 | LJG             | 1.00      | Original release
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	*/
	public function ldtGetStoreInfo()
	{
		$_allStores = Mage::app()->getStores();
		foreach ($_allStores as $_each_storeid => $val) 
		{
			$_storeid = Mage::app()->getStore($_each_storeid)->getStoreId();

			//Store code
			$_storecode = Mage::app()->getStore($_each_storeid)->getCode();

			//website ID
			$_websiteid= Mage::app()->getStore($_each_storeid)->getWebsiteId();

			//Store Name
			$_storename = Mage::app()->getStore($_each_storeid)->getName();

			//Is Active
			$_isactive = Mage::app()->getStore($_each_storeid)->getIsActive();

			//Store Home Url
			$_homeurl = Mage::app()->getStore($_each_storeid)->getHomeUrl();

			// Store info about one store in an array

			$_oneStore = array
				(
					"storeid" 	=> $_storeid	,
					"storecode"	=> $_storecode	,
					"websiteid"	=> $_websiteid	,
					"storename"	=> $_storename	,
					"isactive"	=> $_isactive	,
					"store_homeurl"	=> $_homeurl
				);
	
			// Add store to output array
			$_OutputStores[$_storeid] = $_oneStore;
		}

		return $_OutputStores;
	    }

	/*
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '
        '   Description -   ldtGetMagentoVersion() -   Returns the version of Magento
        '
        ' Amendment Log
        '------------------------------------------------------------------------------------------
        ' Date     | Name            | Vers.     | Description
        '------------------------------------------------------------------------------------------
        ' 05/05/11 | LJG             | 1.00      | Original release
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	*/

	public function ldtGetMagentoVersion()
	{
		$_version = Mage::getVersion();
		return $_version;
	}


	/*
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '
        '   Description -   ldtGetAPIVersion() -   Returns the version of Magento API
        '
        ' Amendment Log
        '------------------------------------------------------------------------------------------
        ' Date     | Name            | Vers.     | Description
        '------------------------------------------------------------------------------------------
        ' 05/05/11 | LJG             | 1.00      | Original release
	' 25/15/11 | LJG             | 1.01      | Added ldtGetProductList() function
	' 21/12/11 | LJG             | 1.02      | Added ldtGetPartialProductList() function
	' 21/12/11 | LJG             | 1.03      | Added ldtGetMaxProductID() function
	' 10/02/12 | LJG             | 1.04      | Updated ldtGetOneProductDetailsByProductID() function
	' 22/02/12 | LJG             | 1.05      | Added ldtGetProductCustomOptions() function 
	'                                        | Added has_options and required_options elements to ldtGetOneProductDetailsByProductID to output
	' 27/02/12 | LJG             | 1.06      | Added ldt_has_custom_options field to query
	' 29/05/12 | LJG             | 1.07      | Added ldtGetOneProductAttributes()
	' 14/08/12 | LJG             | 1.08      | Added ldtGetTablePrefix() and modified all SQL statements to use
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	*/

	public function ldtGetAPIVersion()
	{
		return "1.08";
	}

	/*
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '
        '   Description -   ldtGetOneStoreInfo() -   Returns the version of Magento API
        '
        ' Amendment Log
        '------------------------------------------------------------------------------------------
        ' Date     | Name            | Vers.     | Description
        '------------------------------------------------------------------------------------------
        ' 05/05/11 | LJG             | 1.00      | Original release
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	*/
	public function ldtGetOneStoreInfo($_pcStore_ID)
	{

		$_pcOutputStore = Mage::app()->getStore($_pcStore_ID);

		return $_pcOutputStore;
	}

	/*
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '
        '   Description -   ldtGetRelatedProducts() -   Returns products related to a SKU
        '
        ' Amendment Log
        '------------------------------------------------------------------------------------------
        ' Date     | Name            | Vers.     | Description
        '------------------------------------------------------------------------------------------
        ' 05/05/11 | LJG             | 1.00      | Original release
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	*/

	public function ldtGetRelatedProducts($sku)
	{
		$all_related_sku ='SKU not found';

		if ( $this->ldtGetIDFromSKU( $sku ) != '' ){
			//this loads a specific product using the attribute 'sku'
			$product = Mage::getModel('catalog/product')->loadByAttribute('sku',$sku); 

			$one_sku = "";
			$all_related_sku = "";

			$associated_prods = $product->getTypeInstance()->getUsedProducts();

			foreach ($associated_prods as $assoc_product){

				// Pull out the most relevant items for each related SKU

				$one_sku		= $assoc_product->getSKU();

				$one_product = Mage::getModel('catalog/product')->loadByAttribute('sku',$one_sku);

				$one_attributes	= $one_product->getData();

				$all_related_sku[$one_sku] = $one_attributes;
			}
		}
	                   
		return $all_related_sku;

	}

	/*
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '
        '   Description -   ldtGetAllProductDetails() -   Returns all details about a product
        '
        ' Amendment Log
        '------------------------------------------------------------------------------------------
        ' Date     | Name            | Vers.     | Description
        '------------------------------------------------------------------------------------------
        ' 05/05/11 | LJG             | 1.00      | Original release
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	*/

	public function ldtGetAllProductDetails($sku)
	{
		$one_product = Mage::getModel('catalog/product')->loadByAttribute('sku',$sku);

		$one_attributes	= $one_product->getData();

		return $one_attributes;
	}

	/*
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '
        '   Description -   ldtGetAttributeSetIDFromSKU() - Returns attribute set ID a SKU belongs to
        '
        ' Amendment Log
        '------------------------------------------------------------------------------------------
        ' Date     | Name            | Vers.     | Description
        '------------------------------------------------------------------------------------------
        ' 05/05/11 | LJG             | 1.00      | Original release
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	*/

	public function ldtGetAttributeSetIDFromSKU( $_sku )
	{

		$_product = Mage::getModel('catalog/product')->loadByAttribute('sku',$_sku); 

		$attributeSetModel = Mage::getModel("eav/entity_attribute_set");
		$attributeSetModel->load($_product->getAttributeSetId());
		$attributeSetID = $attributeSetModel->getAttributeSetID();

		return $attributeSetID;
	}


	/*
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '
        '   Description -   ldtGetProductAttributes () - Returns product attributes
        '
        ' Amendment Log
        '------------------------------------------------------------------------------------------
        ' Date     | Name            | Vers.     | Description
        '------------------------------------------------------------------------------------------
        ' 05/05/11 | LJG             | 1.00      | Original release
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	*/

	public function ldtGetProductAttributes($_sku )
	{
		$_product = Mage::getModel('catalog/product')->loadByAttribute('sku',$_sku); 

		$attributeSetModel = Mage::getModel("eav/entity_attribute_set");
		$attributeSetModel->load($_product->getAttributeSetId());

		return $attributeSetModel;
	}

	/*
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '
        '   Description -   ldtGetIDFromSKU() - Returns product ID for a SKU
        '
        ' Amendment Log
        '------------------------------------------------------------------------------------------
        ' Date     | Name            | Vers.     | Description
        '------------------------------------------------------------------------------------------
        ' 05/05/11 | LJG             | 1.00      | Original release
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	*/

	public function ldtGetIDFromSKU( $_sku )
	{
		$_product_ID = '';

		$_product = Mage::getModel('catalog/product')->loadByAttribute('sku',$_sku); 

		if ( $_product != '' )
		{
			$_product_ID = $_product->getIdBySku($_sku);
		}
		return $_product_ID;
	}


	/*
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '
        '   Description -   ldtGetConfigurableProductAttributes() - Returns configurable products for a SKU
        '
        ' Amendment Log
        '------------------------------------------------------------------------------------------
        ' Date     | Name            | Vers.     | Description
        '------------------------------------------------------------------------------------------
        ' 05/05/11 | LJG             | 1.00      | Original release
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	*/

	public function ldtGetConfigurableProductAttributes($_sku, $_store_id)
	{

		$table_prefix=$this->ldtGetTablePrefix();

		$_sql = "select *,
			" . $table_prefix . "catalog_product_super_attribute_label.value as cpsal_value,
			" . $table_prefix . "eav_attribute_option_value.value as eaov_value
			from " . $table_prefix . "catalog_product_entity
				inner join " . $table_prefix . "catalog_product_super_attribute on
					" . $table_prefix . "catalog_product_super_attribute.product_id = " . $table_prefix . "catalog_product_entity.entity_id
				inner join " . $table_prefix . "catalog_product_super_attribute_label on
					" . $table_prefix . "catalog_product_super_attribute.product_super_attribute_id = " . $table_prefix . "catalog_product_super_attribute_label.product_super_attribute_id
				inner join " . $table_prefix . "eav_attribute_option on
					" . $table_prefix . "eav_attribute_option.attribute_id =  " . $table_prefix . "catalog_product_super_attribute.attribute_id
				inner " . $table_prefix . "join eav_attribute on
					" . $table_prefix . "eav_attribute.attribute_id = " . $table_prefix . "catalog_product_super_attribute.attribute_id
				inner join " . $table_prefix . "eav_attribute_option_value on
					" . $table_prefix . "eav_attribute_option_value.option_id = " . $table_prefix . "eav_attribute_option.option_id
			where " . $table_prefix . "catalog_product_entity.sku = '$_sku' and " . $table_prefix . "eav_attribute_option_value.store_id = $_store_id ;" ;

		$_getData = Mage::getSingleton('core/resource')->getConnection('core_read')->fetchAll($_sql);  

		return $_getData;
	}


	/*
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '
        '   Description -   ldtGetAttributeTable() - Returns all atribute table
        '
        ' Amendment Log
        '------------------------------------------------------------------------------------------
        ' Date     | Name            | Vers.     | Description
        '------------------------------------------------------------------------------------------
        ' 05/05/11 | LJG             | 1.00      | Original release
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	*/

	public function ldtGetAttributeTable()

	{
		$table_prefix=$this->ldtGetTablePrefix();
		$_sql = "select * from " . $table_prefix . "eav_attribute_option_value;";
		$_getData = Mage::getSingleton('core/resource')->getConnection('core_read')->fetchAll($_sql);  

		return $_getData;
	}

	/*
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '
        '   Description -   ldtWriteToFile() - Write to a local file
        '
        ' Amendment Log
        '------------------------------------------------------------------------------------------
        ' Date     | Name            | Vers.     | Description
        '------------------------------------------------------------------------------------------
        ' 05/05/11 | LJG             | 1.00      | Original release
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	*/

	public function ldtWriteToFile( $file, $data )
	{

		$handle = fopen( $file, 'a');	

		fwrite( $handle, $data . chr(13) . chr(10) );
	
		fclose( $handle );

		return;
	}

	/*
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '
        '   Description -   ldtGetProductList() - Export selected properties of all products
        '
        ' Amendment Log
        '------------------------------------------------------------------------------------------
        ' Date     | Name            | Vers.     | Description
        '------------------------------------------------------------------------------------------
        ' 25/11/11 | LJG             | 1.00      | Original release
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	*/

	public function ldtGetProductList()
	{
		$all_skus = array();
		$sku_array = array();	
		$collection = Mage::getModel('catalog/product')->getCollection()
			->addAttributeToSelect('*'); // select all attributes

		foreach ($collection as $product ){
			// Pull out the most relevant items for each related SKU

			$one_sku	= $product->getSKU();			// get SKU
			$one_name	= $product->getName();			// get name
			$one_type 	= $product->getTypeID();		// get product type
			$one_productID	= $product->getIdBySku($one_sku);	// get product ID

			// Store info about one SKU in an array
			$sku_array = array
				(
					"product_id"	=> $one_productID	,
					"sku"		=> $one_sku		,
					"name"		=> $one_name		,
					"type"		=> $one_type	
				);
	
			// Add SKU to output array
			$all_skus[$one_productID] = $sku_array;
		};


	return $all_skus;
	}

	/*
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '
        '   Description -   ldtGetProductCustomOptions() -   Returns some custom details about a product via Product_ID
        '
        ' Amendment Log
        '------------------------------------------------------------------------------------------
        ' Date     | Name            | Vers.     | Description
        '------------------------------------------------------------------------------------------
        ' 22/02/12 | LJG             | 1.00      | Original release
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	*/

	public function ldtGetProductCustomOptions( $incoming_Product_ID )
	{

	$table_prefix=$this->ldtGetTablePrefix();

	$_sql = "SELECT distinct " . $table_prefix . "catalog_product_option.product_id,
		" . $table_prefix . "catalog_product_option_type_value.sku, 
		" . $table_prefix . "catalog_product_option.option_id, 
		" . $table_prefix . "catalog_product_option.type as attr_type,
		" . $table_prefix . "catalog_product_option_title.title as attr_title, 
		" . $table_prefix . "catalog_product_option.is_require as attr_is_require, 
		" . $table_prefix . "catalog_product_option_type_value.sort_order as attr_sort_order,
		" . $table_prefix . "catalog_product_option_type_title.title,
		" . $table_prefix . "catalog_product_option_type_value.option_type_id, 
		" . $table_prefix . "catalog_product_option_type_price.price,
		" . $table_prefix . "catalog_product_option_type_price.price_type 
		  FROM " . $table_prefix . "catalog_product_option 
		  INNER JOIN " . $table_prefix . "catalog_product_option_type_value 
		  ON " . $table_prefix . "catalog_product_option.option_id = " . $table_prefix . "catalog_product_option_type_value.option_id 
		  INNER JOIN " . $table_prefix . "catalog_product_option_type_title
		  ON " . $table_prefix . "catalog_product_option_type_value.option_type_id = " . $table_prefix . "catalog_product_option_type_title.option_type_id
		  INNER JOIN " . $table_prefix . "catalog_product_option_title 
		  ON " . $table_prefix . "catalog_product_option.option_id = " . $table_prefix . "catalog_product_option_title.option_title_id
		  INNER JOIN " . $table_prefix . "catalog_product_option_type_price
		  ON " . $table_prefix . "catalog_product_option_type_value.option_type_id = " . $table_prefix . "catalog_product_option_type_price.option_type_id
		        WHERE " . $table_prefix . "catalog_product_option.product_id = " . $incoming_Product_ID . " and " . $table_prefix . "catalog_product_option_type_value.sku IS NOT NULL ";

		$_getData = Mage::getSingleton('core/resource')->getConnection('core_read')->fetchAll($_sql);  

	return $_getData;
	}

	/*
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '
        '   Description -   ldtGetOneProductDetailsByProductID() -   Returns some details about a product via Product_ID
        '
        ' Amendment Log
        '------------------------------------------------------------------------------------------
        ' Date     | Name            | Vers.     | Description
        '------------------------------------------------------------------------------------------
        ' 13/12/11 | LJG             | 1.00      | Original release
	' 10/02/12 | LJG             | 1.04      | Updated to add quantity_to_receive and $return_deleted parameters
	' 22/02/12 | LJG             | 1.05      | Added has_options and required_options elements to output.
	'          |                 |           | Also corrected issue of missing last id when retrieving in 1 batch.
	' 27/02/12 | LJG             | 1.06      | Added ldt_has_custom_options field to query
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	*/

	public function ldtGetOneProductDetailsByProductID( $incoming_Product_ID, $quantity_to_receive, $return_deleted )
	{
		$table_prefix=$this->ldtGetTablePrefix();

		$max_id_array = $this->ldtGetMaxProductID();

		foreach ($max_id_array as $one_value ) {
			foreach ( $one_value as $two_value ) {
			};
		};
		$max_id = $two_value;

		$total_in = $incoming_Product_ID + $quantity_to_receive;
		$end = $total_in - 1;
		if ( $total_in > $max_id ) {
			$end = $max_id ;
		};

		// Pull the attribute id
		$_sql = "SELECT attribute_id FROM  " . $table_prefix . "eav_entity_type 
				inner join  " . $table_prefix . "eav_attribute 
					on  " . $table_prefix . "eav_attribute.entity_type_id =  " . $table_prefix . "eav_entity_type.entity_type_id 
				where entity_type_code = 'catalog_product' and attribute_code = 'name' ";

		$_getData = Mage::getSingleton('core/resource')->getConnection('core_read')->fetchAll($_sql); 
		foreach ($_getData as $one_value ) {
			foreach ( $one_value as $two_value ) {
			};
		};
		$attribute_id = $two_value;

		$_sql = "select 'false' as Deleted, 
				 " . $table_prefix . "catalog_product_entity.entity_id as product_id,
				 " . $table_prefix . "catalog_product_entity.sku,
				 " . $table_prefix . "catalog_product_entity_varchar.value as name, 
				 " . $table_prefix . "catalog_product_entity.type_id as type,
				 " . $table_prefix . "catalog_product_entity.has_options,
				 " . $table_prefix . "catalog_product_entity.required_options,
	                        if(  " . $table_prefix . "catalog_product_option.product_id > 0, 'yes', 'no') as ldt_has_custom_options
			from  " . $table_prefix . "catalog_product_entity 
				left join  " . $table_prefix . "catalog_product_entity_varchar 
					on  " . $table_prefix . "catalog_product_entity.entity_id =  " . $table_prefix . "catalog_product_entity_varchar.entity_id 
                                left join  " . $table_prefix . "catalog_product_option
                                        on  " . $table_prefix . "catalog_product_entity.entity_id  =  " . $table_prefix . "catalog_product_option.product_id
		        where  " . $table_prefix . "catalog_product_entity.entity_id BETWEEN " . $incoming_Product_ID . " AND " . $end .
			" and  " . $table_prefix . "catalog_product_entity_varchar.attribute_id = " . $attribute_id .  
			" order by  " . $table_prefix . "catalog_product_entity.entity_id ;";

		$_getData = Mage::getSingleton('core/resource')->getConnection('core_read')->fetchAll($_sql);  

	return $_getData;
	}

/*
	{
		$max_id_array = $this->ldtGetMaxProductID();

		foreach ($max_id_array as $one_value ) {
			foreach ( $one_value as $two_value ) {
			};
		};
		$max_id = $two_value;

		$all_skus = "";
		$sku_array = "";

		for ($i=$incoming_Product_ID ; $i<$incoming_Product_ID + $quantity_to_receive ; $i++)
		{
			// Exit loop if we exceed max product ID
			if ( $i > $max_id ) {
				break;
			}

			$product_is_deleted = "false";
			$return_product = "false";

			$sku_array = array
				(
					"product_id"	=> "Does Not Exist"	,
					"incoming_id"	=> $i
				);

			$product = Mage::getModel('catalog/product')->load( $i );  //load the product 
	
			$one_is_deleted	= $product->isDeleted();		// Deleted status
			$one_sku	= $product->getSKU();			// get SKU
			$one_name	= $product->getName();			// get name
			$one_type 	= $product->getTypeID();		// get product type
			$one_productID	= $product->getIdBySku($one_sku);	// get product ID

			$product_is_deleted = $product->isDeleted();

			if ( $one_sku == '' ) {
				$product_is_deleted = "true";
			}
			else{
				$product_is_deleted = "false";
			}

			// Store info about one SKU in an array

			// We check if we are returning deleted products or not.


			if ( $return_deleted == "true" ) {
				$return_product = "true";
			}else{
				if ( $product_is_deleted == "true") {
					$return_product = "false";
				}
				else{
					$return_product = "true";
				}
			}

			$sku_array = array
				(
					"Deleted"	=> $one_is_deleted	,
					"product_id"	=> $one_productID	,
					"sku"		=> $one_sku		,
					"name"		=> $one_name		,
					"type"		=> $one_type		,
					"loop_id"	=> $i
				);
	
			// Add SKU info to output array
			if ( $return_product == "true" ) {
				$all_skus[ $i ] = $sku_array;
			}else{
			}
		}
		return $all_skus;
	}
*/
	/*
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '
        '   Description -   ldtGetPartialProductList() - Export selected properties of all products
        '
        ' Amendment Log
        '------------------------------------------------------------------------------------------
        ' Date     | Name            | Vers.     | Description
        '------------------------------------------------------------------------------------------
        ' 21/12/11 | LJG             | 1.00      | Original release
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	*/

	public function ldtGetPartialProductList()
	{

		$all_skus = array();
		$sku_array = array();	
		$collection = Mage::getModel('catalog/product')->getCollection();
		
		$collection->addAttributeToFilter('entity_id', array('in'=>array(24,33)));

		foreach ($collection as $product ){
			// Pull out the most relevant items for each related SKU

			$one_is_deleted	= $product->isDeleted();		// Deleted status
			$one_sku	= $product->getSKU();			// get SKU
			$one_name	= $product->getName();			// get name
			$one_type 	= $product->getTypeID();		// get product type
			$one_productID	= $product->getIdBySku($one_sku);	// get product ID

			// Store info about one SKU in an array
			$sku_array = array
				(
					"product_id"	=> $one_productID	,
					"Deleted"	=> $one_is_deleted	,
					"sku"		=> $one_sku		,
					"name"		=> $one_name		,
					"type"		=> $one_type	
				);
	
			// Add SKU to output array
			$all_skus[$one_productID] = $sku_array;
		};


	return $all_skus;
	}

	/*
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '
        '   Description -   ldtGetMaxProductID() - Returns highest product ID in use
        '
        ' Amendment Log
        '------------------------------------------------------------------------------------------
        ' Date     | Name            | Vers.     | Description
        '------------------------------------------------------------------------------------------
        ' 21/12/11 | LJG             | 1.00      | Original release
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	*/
	public function ldtGetMaxProductID()
	{
		$table_prefix=$this->ldtGetTablePrefix();

		$_sql = "select max(entity_id) from " . $table_prefix . "catalog_product_entity;";
		$_getData = Mage::getSingleton('core/resource')->getConnection('core_read')->fetchAll($_sql);  

	return $_getData;
	}

	/*
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '
        '   Description -   ldtOrdersUpdatedAfter() - Returns list of orders modified after a given datetime
        '
        ' Amendment Log
        '------------------------------------------------------------------------------------------
        ' Date     | Name            | Vers.     | Description
        '------------------------------------------------------------------------------------------
        ' 09/01/12 | LJG             | 1.00      | Original release
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	*/

	public function ldtOrdersUpdatedAfter($sDateTime)
	{
		$table_prefix=$this->ldtGetTablePrefix();
		$_sql = "select increment_id,original_increment_id,relation_parent_real_id, updated_at from " . $table_prefix . "sales_flat_order where updated_at >= '" . $sDateTime . "' ;";

		$_getData = Mage::getSingleton('core/resource')->getConnection('core_read')->fetchAll($_sql);  
	return $_getData;
	}

	/*
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '
        '   Description -   ldtOrdersUpdatedAfter() - Returns list of attrbutes for a product ID and attribute set
        '
        ' Amendment Log
        '------------------------------------------------------------------------------------------
        ' Date     | Name            | Vers.     | Description
        '------------------------------------------------------------------------------------------
        ' 25/05/12 | LJG             | 1.00      | Original release
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	*/

	public function ldtGetOneProductAttributes( $product_id, $attribute_set_id)
	{
		$table_prefix=$this->ldtGetTablePrefix();

		$_sql = "SELECT " . $table_prefix . "catalog_product_super_attribute.product_super_attribute_id,
				" . $table_prefix . "catalog_product_super_attribute.product_id,
				" . $table_prefix . "catalog_product_super_attribute.attribute_id,
				position,
				attribute_code,
				attribute_model,
				backend_model,
				backend_type,
				backend_table,
				frontend_model,
				frontend_input,
				frontend_label,
				frontend_class,
				source_model,
				is_required,
				is_user_defined,
				default_value,
				is_unique,
				note,
				entity_attribute_id,
				" . $table_prefix . "eav_entity_attribute.entity_type_id,
				attribute_set_id,
				attribute_group_id,
				sort_order
				FROM " . $table_prefix . "catalog_product_super_attribute
				left join " . $table_prefix . "eav_attribute on " . $table_prefix . "eav_attribute.attribute_id = " . $table_prefix . "catalog_product_super_attribute.attribute_id
				left join " . $table_prefix . "eav_entity_attribute on " . $table_prefix . "eav_entity_attribute.attribute_id = " . $table_prefix . "catalog_product_super_attribute.attribute_id
				where product_id = " . $product_id . " and attribute_set_id = " . $attribute_set_id ;

		$_getData = Mage::getSingleton('core/resource')->getConnection('core_read')->fetchAll($_sql);  
	return $_getData;
	}

	/*
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '
        '   Description -   ldtGetTablePrefix() - Returns database table prefix
        '
        ' Amendment Log
        '------------------------------------------------------------------------------------------
        ' Date     | Name            | Vers.     | Description
        '------------------------------------------------------------------------------------------
        ' 14/08/12 | LJG             | 1.00      | Original release
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	*/

	public function ldtGetTablePrefix()
	{
	
		$prefix = Mage::getConfig()->getTablePrefix();
		return $prefix;
	}
}

//$this->ldtWriteToFile( "Lloyd", "Product is deleted " . $i . " " . $product_is_deleted );
//$this->ldtWriteToFile( "Lloyd", "Return Product " . $i . " " . $return_product);


?>


