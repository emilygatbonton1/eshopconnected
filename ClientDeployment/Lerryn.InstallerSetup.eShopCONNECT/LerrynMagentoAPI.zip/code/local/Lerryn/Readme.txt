﻿This software is the copyright of Lerryn Business Solutions Ltd and
may not be copied, duplicated or modified other than as permitted
in the licence agreement.

      � 2012 - 2013  Lerryn Buniness Solutions Ltd
                     2 East View
                     Bessie Lane
                     Bradwell
                     Hope Valley
                     S33 9HZ

Tel +44 (0)1433 621584
Email Support@lerryn.com

Lerryn is a Trademark of Lerryn Business Solutions Ltd
eShopCONNECT is a Trademark of Lerryn Business Solutions Ltd
-------------------------------------------------------------------

Lerryn API extension for Magento.
v1.11
