<?php



//
// eShopCONNECT - Magento API
// Module: install-0.1.11.php
//
// This software is the copyright of Lerryn Business Solutions Ltd and
// may not be copied, duplicated or modified other than as permitted
// in the licence agreement.
//
//       � 2012 - 2013  Lerryn Buniness Solutions Ltd
//                      2 East View
//                      Bessie Lane
//                      Bradwell
//                      Hope Valley
//                      S33 9HZ
//
// Tel +44 (0)1433 621584
// Email Support@lerryn.com
//
// Lerryn is a Trademark of Lerryn Business Solutions Ltd
// eShopCONNECT is a Trademark of Lerryn Business Solutions Ltd
// -------------------------------------------------------------------

    /*
      ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
      '
      '   Description -   API Installer - creates Log table for attribute save

      '
      ' Amendment Log
      '------------------------------------------------------------------------------------------
      ' Date     | Name            | Vers.     | Description
      '------------------------------------------------------------------------------------------
      ' 20/10/13 | TJS/Aydus       | 1.10      | Function added by davidt@aydus.com and amended by TJS to include table prefix

      ' 28/10/13 | TJS             | 1.11.     | Corrected adding of table name prefix and renamed file for version number change
      '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
 */

$installer = $this;

$installer->startSetup();

//echo 'LBSapi setup started ...<br/>';


$tableName = Mage::getConfig()->getTablePrefix()."lerryn_lbsapi_attributesave_log";


$attributeSaveLogTable = "CREATE TABLE IF NOT EXISTS `" . $tableName ."` (
  `attribute_id` int(11) unsigned NOT NULL DEFAULT '0',
  `attribute_modification_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`attribute_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8";


$installer->run($attributeSaveLogTable);
//echo 'LBSapi setup complete.';

$installer->endSetup();