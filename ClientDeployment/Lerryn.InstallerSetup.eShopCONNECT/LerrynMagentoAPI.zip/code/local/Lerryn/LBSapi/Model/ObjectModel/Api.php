﻿<?php

//
// eShopCONNECT - Magento API
// Module: Api.php
//
// This software is the copyright of Lerryn Business Solutions Ltd and
// may not be copied, duplicated or modified other than as permitted
// in the licence agreement.
//
//       © 2012 - 2013  Lerryn Buniness Solutions Ltd
//                      2 East View
//                      Bessie Lane
//                      Bradwell
//                      Hope Valley
//                      S33 9HZ
//
// Tel +44 (0)1433 621584
// Email Support@lerryn.com
//
// Lerryn is a Trademark of Lerryn Business Solutions Ltd
// eShopCONNECT is a Trademark of Lerryn Business Solutions Ltd
// -------------------------------------------------------------------
class Lerryn_LBSapi_Model_ObjectModel_api extends Mage_Api_Model_Resource_Abstract {
    /*
      ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
      '
      '   Description -   lbsGetStoreInfo() -   Returns information about a Magento store
      '
      ' Amendment Log
      '------------------------------------------------------------------------------------------
      ' Date     | Name            | Vers.     | Description
      '------------------------------------------------------------------------------------------
      ' 05/05/11 | LJG             | 1.00      | Original release
      ' 21/09/13 | TJS             | 1.09      | Changed function name prefix from ldt to lbs
      '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
     */

    public function lbsGetStoreInfo() {
        $_allStores = Mage::app()->getStores();
        foreach ($_allStores as $_each_storeid => $val) {
            $_storeid = Mage::app()->getStore($_each_storeid)->getStoreId();

            //Store code
            $_storecode = Mage::app()->getStore($_each_storeid)->getCode();

            //website ID
            $_websiteid = Mage::app()->getStore($_each_storeid)->getWebsiteId();

            //Store Name
            $_storename = Mage::app()->getStore($_each_storeid)->getName();

            //Is Active
            $_isactive = Mage::app()->getStore($_each_storeid)->getIsActive();

            //Store Home Url
            $_homeurl = Mage::app()->getStore($_each_storeid)->getHomeUrl();

            // Store info about one store in an array

            $_oneStore = array
                (
                "storeid" => $_storeid,
                "storecode" => $_storecode,
                "websiteid" => $_websiteid,
                "storename" => $_storename,
                "isactive" => $_isactive,
                "store_homeurl" => $_homeurl
            );

            // Add store to output array
            $_OutputStores[$_storeid] = $_oneStore;
        }

        return $_OutputStores;
    }

    /*
      ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
      '
      '   Description -   lbsGetMagentoVersion() -   Returns the version of Magento
      '
      ' Amendment Log
      '------------------------------------------------------------------------------------------
      ' Date     | Name            | Vers.     | Description
      '------------------------------------------------------------------------------------------
      ' 05/05/11 | LJG             | 1.00      | Original release
      '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
     */

    public function lbsGetMagentoVersion() {
        $_version = Mage::getVersion();
        return $_version;
    }

    /*
      ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
      '
      '   Description -   lbsGetAPIVersion() -   Returns the version of Magento API
      '
      ' Amendment Log
      '------------------------------------------------------------------------------------------
      ' Date     | Name            | Vers.     | Description
      '------------------------------------------------------------------------------------------
      ' 05/05/11 | LJG             | 1.00      | Original release
      ' 21/09/13 | TJS             | 1.09      | Changed function name prefix from ldt to lbs
      ' 20/10/13 | TJS             | 1.10      | Updated version
      ' 01/11/13 | TJS             | 1.11      | Updated version, added Magento version to return data
      '                                        | and added code to create attribute log table if not present
      '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
     */

    public function lbsGetAPIVersion() {

	$tableName = Mage::getConfig()->getTablePrefix()."lerryn_lbsapi_attributesave_log";

	$write = Mage::getSingleton('core/resource')->getConnection('core_write');


	
$attributeSaveLogTable = "CREATE TABLE IF NOT EXISTS `" . $tableName ."` (
  `attribute_id` int(11) unsigned NOT NULL DEFAULT '0',
  `attribute_modification_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`attribute_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8";


	$write->query($attributeSaveLogTable);


        $_version = Mage::getVersion();
        $returndata = array
            (
                "APIVersion" => "1.11",
                "MagentoVersion" => $_version
            );
        return $returndata ;
    }

    /*
      ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
      '
      '   Description -   lbsGetOneStoreInfo() -   Returns details related to a store
      '
      ' Amendment Log
      '------------------------------------------------------------------------------------------
      ' Date     | Name            | Vers.     | Description
      '------------------------------------------------------------------------------------------
      ' 05/05/11 | LJG             | 1.00      | Original release
      '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
     */

    public function lbsGetOneStoreInfo($_pcStore_ID) {

        $_pcOutputStore = Mage::app()->getStore($_pcStore_ID);

        return $_pcOutputStore;
    }

    /*
      ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
      '
      '   Description -   lbsGetRelatedProducts() -   Returns products related to a SKU
      '
      ' Amendment Log
      '------------------------------------------------------------------------------------------
      ' Date     | Name            | Vers.     | Description
      '------------------------------------------------------------------------------------------
      ' 05/05/11 | LJG             | 1.00      | Original release
      ' 21/09/13 | TJS             | 1.09      | Changed function name prefix from ldt to lbs
      '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
     */

    public function lbsGetRelatedProducts($sku) {
        $all_related_sku = 'SKU not found';

        if ($this->lbsGetIDFromSKU($sku) != '') {
            //this loads a specific product using the attribute 'sku'
            $product = Mage::getModel('catalog/product')->loadByAttribute('sku', $sku);

            $one_sku = "";
            $all_related_sku = "";

            $associated_prods = $product->getTypeInstance()->getUsedProducts();

            foreach ($associated_prods as $assoc_product) {

                // Pull out the most relevant items for each related SKU

                $one_sku = $assoc_product->getSKU();

                $one_product = Mage::getModel('catalog/product')->loadByAttribute('sku', $one_sku);

                $one_attributes = $one_product->getData();

                $all_related_sku[$one_sku] = $one_attributes;
            }
        }

        return $all_related_sku;
    }

    /*
      ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
      '
      '   Description -   lbsGetAllProductDetails() -   Returns all details about a product
      '
      ' Amendment Log
      '------------------------------------------------------------------------------------------
      ' Date     | Name            | Vers.     | Description
      '------------------------------------------------------------------------------------------
      ' 05/05/11 | LJG             | 1.00      | Original release
      ' 21/09/13 | TJS             | 1.09      | Changed function name prefix from ldt to lbs
      '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
     */

    public function lbsGetAllProductDetails($sku) {
        $one_product = Mage::getModel('catalog/product')->loadByAttribute('sku', $sku);

        $one_attributes = $one_product->getData();

        return $one_attributes;
    }

    /*
      ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
      '
      '   Description -   lbsGetAttributeSetIDFromSKU() - Returns attribute set ID a SKU belongs to
      '
      ' Amendment Log
      '------------------------------------------------------------------------------------------
      ' Date     | Name            | Vers.     | Description
      '------------------------------------------------------------------------------------------
      ' 05/05/11 | LJG             | 1.00      | Original release
      ' 21/09/13 | TJS             | 1.09      | Changed function name prefix from ldt to lbs
      '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
     */

    public function lbsGetAttributeSetIDFromSKU($_sku) {

        $_product = Mage::getModel('catalog/product')->loadByAttribute('sku', $_sku);

        $attributeSetModel = Mage::getModel("eav/entity_attribute_set");
        $attributeSetModel->load($_product->getAttributeSetId());
        $attributeSetID = $attributeSetModel->getAttributeSetID();

        return $attributeSetID;
    }

    /*
      ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
      '
      '   Description -   lbsGetProductAttributes () - Returns product attributes
      '
      ' Amendment Log
      '------------------------------------------------------------------------------------------
      ' Date     | Name            | Vers.     | Description
      '------------------------------------------------------------------------------------------
      ' 05/05/11 | LJG             | 1.00      | Original release
      ' 21/09/13 | TJS             | 1.09      | Changed function name prefix from ldt to lbs
      '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
     */

    public function lbsGetProductAttributes($_sku) {
        $_product = Mage::getModel('catalog/product')->loadByAttribute('sku', $_sku);

        $attributeSetModel = Mage::getModel("eav/entity_attribute_set");
        $attributeSetModel->load($_product->getAttributeSetId());

        return $attributeSetModel;
    }

    /*
      ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
      '
      '   Description -   lbsGetIDFromSKU() - Returns product ID for a SKU
      '
      ' Amendment Log
      '------------------------------------------------------------------------------------------
      ' Date     | Name            | Vers.     | Description
      '------------------------------------------------------------------------------------------
      ' 05/05/11 | LJG             | 1.00      | Original release
      ' 21/09/13 | TJS             | 1.09      | Changed function name prefix from ldt to lbs
      '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
     */

    public function lbsGetIDFromSKU($_sku) {
        $_product_ID = '';

        $_product = Mage::getModel('catalog/product')->loadByAttribute('sku', $_sku);

        if ($_product != '') {
            $_product_ID = $_product->getIdBySku($_sku);
        }
        return $_product_ID;
    }

    /*
      ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
      '
      '   Description -   lbsGetConfigurableProductAttributes() - Returns configurable products for a SKU
      '
      ' Amendment Log
      '------------------------------------------------------------------------------------------
      ' Date     | Name            | Vers.     | Description
      '------------------------------------------------------------------------------------------
      ' 05/05/11 | LJG             | 1.00      | Original release
      ' 14/08/12 | LJG             | 1.08      | Modified SQL statements to use lbsGetTablePrefix()
      ' 21/09/13 | TJS             | 1.09      | Changed function name prefix from ldt to lbs
      '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
     */

    public function lbsGetConfigurableProductAttributes($_sku, $_store_id) {

        $table_prefix = $this->lbsGetTablePrefix();

        $_sql = "select *,
			" . $table_prefix . "catalog_product_super_attribute_label.value as cpsal_value,
			" . $table_prefix . "eav_attribute_option_value.value as eaov_value
			from " . $table_prefix . "catalog_product_entity
				inner join " . $table_prefix . "catalog_product_super_attribute on
					" . $table_prefix . "catalog_product_super_attribute.product_id = " . $table_prefix . "catalog_product_entity.entity_id
				inner join " . $table_prefix . "catalog_product_super_attribute_label on
					" . $table_prefix . "catalog_product_super_attribute.product_super_attribute_id = " . $table_prefix . "catalog_product_super_attribute_label.product_super_attribute_id
				inner join " . $table_prefix . "eav_attribute_option on
					" . $table_prefix . "eav_attribute_option.attribute_id =  " . $table_prefix . "catalog_product_super_attribute.attribute_id
				inner " . $table_prefix . "join eav_attribute on
					" . $table_prefix . "eav_attribute.attribute_id = " . $table_prefix . "catalog_product_super_attribute.attribute_id
				inner join " . $table_prefix . "eav_attribute_option_value on
					" . $table_prefix . "eav_attribute_option_value.option_id = " . $table_prefix . "eav_attribute_option.option_id
			where " . $table_prefix . "catalog_product_entity.sku = '$_sku' and " . $table_prefix . "eav_attribute_option_value.store_id = $_store_id ;";

        $_getData = Mage::getSingleton('core/resource')->getConnection('core_read')->fetchAll($_sql);

        return $_getData;
    }

    /*
      ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
      '
      '   Description -   lbsGetAttributeTable() - Returns all atribute table
      '
      ' Amendment Log
      '------------------------------------------------------------------------------------------
      ' Date     | Name            | Vers.     | Description
      '------------------------------------------------------------------------------------------
      ' 05/05/11 | LJG             | 1.00      | Original release
      ' 14/08/12 | LJG             | 1.08      | Modified SQL statements to use lbsGetTablePrefix()
      ' 21/09/13 | TJS             | 1.09      | Changed function name prefix from ldt to lbs
      '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
     */

    public function lbsGetAttributeTable() {
        $table_prefix = $this->lbsGetTablePrefix();
        $_sql = "select * from " . $table_prefix . "eav_attribute_option_value;";
        $_getData = Mage::getSingleton('core/resource')->getConnection('core_read')->fetchAll($_sql);

        return $_getData;
    }

    /*
      ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
      '
      '   Description -   lbsWriteToFile() - Write to a local file
      '
      ' Amendment Log
      '------------------------------------------------------------------------------------------
      ' Date     | Name            | Vers.     | Description
      '------------------------------------------------------------------------------------------
      ' 05/05/11 | LJG             | 1.00      | Original release
      ' 21/09/13 | TJS             | 1.09      | Changed function name prefix from ldt to lbs
      '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
     */

    public function lbsWriteToFile($file, $data) {

        $handle = fopen($file, 'a');

        fwrite($handle, $data . chr(13) . chr(10));

        fclose($handle);

        return;
    }

    /*
      ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
      '
      '   Description -   lbsGetProductList() - Export selected properties of all products
      '
      ' Amendment Log
      '------------------------------------------------------------------------------------------
      ' Date     | Name            | Vers.     | Description
      '------------------------------------------------------------------------------------------
      ' 25/15/11 | LJG             | 1.01      | Added ldtGetProductList() function
      ' 21/09/13 | TJS             | 1.09      | Changed function name prefix from ldt to lbs
      '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
     */

    public function lbsGetProductList() {
        $all_skus = array();
        $sku_array = array();
        $collection = Mage::getModel('catalog/product')->getCollection()
                ->addAttributeToSelect('*'); // select all attributes

        foreach ($collection as $product) {
            // Pull out the most relevant items for each related SKU

            $one_sku = $product->getSKU();   // get SKU
            $one_name = $product->getName();   // get name
            $one_type = $product->getTypeID();  // get product type
            $one_productID = $product->getIdBySku($one_sku); // get product ID
            // Store info about one SKU in an array
            $sku_array = array
                (
                "product_id" => $one_productID,
                "sku" => $one_sku,
                "name" => $one_name,
                "type" => $one_type
            );

            // Add SKU to output array
            $all_skus[$one_productID] = $sku_array;
        };


        return $all_skus;
    }

    /*
      ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
      '
      '   Description -   lbsGetProductCustomOptions() -   Returns some custom details about a product via Product_ID
      '
      ' Amendment Log
      '------------------------------------------------------------------------------------------
      ' Date     | Name            | Vers.     | Description
      '------------------------------------------------------------------------------------------
      ' 22/02/12 | LJG             | 1.05      | Added function
      ' 14/08/12 | LJG             | 1.08      | Modified SQL statements to use lbsGetTablePrefix()
      ' 21/09/13 | TJS             | 1.09      | Changed function name prefix from ldt to lbs
      '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
     */

    public function lbsGetProductCustomOptions($incoming_Product_ID) {

        $table_prefix = $this->lbsGetTablePrefix();

        $_sql = "SELECT distinct " . $table_prefix . "catalog_product_option.product_id,
		" . $table_prefix . "catalog_product_option_type_value.sku, 
		" . $table_prefix . "catalog_product_option.option_id, 
		" . $table_prefix . "catalog_product_option.type as attr_type,
		" . $table_prefix . "catalog_product_option_title.title as attr_title, 
		" . $table_prefix . "catalog_product_option.is_require as attr_is_require, 
		" . $table_prefix . "catalog_product_option_type_value.sort_order as attr_sort_order,
		" . $table_prefix . "catalog_product_option_type_title.title,
		" . $table_prefix . "catalog_product_option_type_value.option_type_id, 
		" . $table_prefix . "catalog_product_option_type_price.price,
		" . $table_prefix . "catalog_product_option_type_price.price_type 
		  FROM " . $table_prefix . "catalog_product_option 
		  INNER JOIN " . $table_prefix . "catalog_product_option_type_value 
		  ON " . $table_prefix . "catalog_product_option.option_id = " . $table_prefix . "catalog_product_option_type_value.option_id 
		  INNER JOIN " . $table_prefix . "catalog_product_option_type_title
		  ON " . $table_prefix . "catalog_product_option_type_value.option_type_id = " . $table_prefix . "catalog_product_option_type_title.option_type_id
		  INNER JOIN " . $table_prefix . "catalog_product_option_title 
		  ON " . $table_prefix . "catalog_product_option.option_id = " . $table_prefix . "catalog_product_option_title.option_title_id
		  INNER JOIN " . $table_prefix . "catalog_product_option_type_price
		  ON " . $table_prefix . "catalog_product_option_type_value.option_type_id = " . $table_prefix . "catalog_product_option_type_price.option_type_id
		        WHERE " . $table_prefix . "catalog_product_option.product_id = " . $incoming_Product_ID . " and " . $table_prefix . "catalog_product_option_type_value.sku IS NOT NULL ";

        $_getData = Mage::getSingleton('core/resource')->getConnection('core_read')->fetchAll($_sql);

        return $_getData;
    }

    /*
      ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
      '
      '   Description -   lbsGetOneProductDetailsByProductID() -   Returns some details about a product via Product_ID
      '
      ' Amendment Log
      '------------------------------------------------------------------------------------------
      ' Date     | Name            | Vers.     | Description
      '------------------------------------------------------------------------------------------
      ' 13/12/11 | LJG             | 1.00      | Original release
      ' 10/02/12 | LJG             | 1.04      | Updated to add quantity_to_receive and $return_deleted parameters
      ' 22/02/12 | LJG             | 1.05      | Added has_options and required_options elements to output.
      '          |                 |           | Also corrected issue of missing last id when retrieving in 1 batch.
      ' 27/02/12 | LJG             | 1.06      | Added ldt_has_custom_options field to query
      ' 14/08/12 | LJG             | 1.08      | Modified SQL statements to use lbsGetTablePrefix()
      ' 21/09/13 | TJS             | 1.09      | Changed function name prefix from ldt to lbs
      '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
     */

    public function lbsGetOneProductDetailsByProductID($incoming_Product_ID, $quantity_to_receive, $return_deleted) {
        $table_prefix = $this->lbsGetTablePrefix();

        $max_id_array = $this->lbsGetMaxProductID();

        foreach ($max_id_array as $one_value) {
            foreach ($one_value as $two_value) {
                
            };
        };
        $max_id = $two_value;

        $total_in = $incoming_Product_ID + $quantity_to_receive;
        $end = $total_in - 1;
        if ($total_in > $max_id) {
            $end = $max_id;
        };

        // Pull the attribute id
        $_sql = "SELECT attribute_id FROM  " . $table_prefix . "eav_entity_type 
				inner join  " . $table_prefix . "eav_attribute 
					on  " . $table_prefix . "eav_attribute.entity_type_id =  " . $table_prefix . "eav_entity_type.entity_type_id 
				where entity_type_code = 'catalog_product' and attribute_code = 'name' ";

        $_getData = Mage::getSingleton('core/resource')->getConnection('core_read')->fetchAll($_sql);
        foreach ($_getData as $one_value) {
            foreach ($one_value as $two_value) {
                
            };
        };
        $attribute_id = $two_value;

        $_sql = "select 'false' as Deleted, 
				 " . $table_prefix . "catalog_product_entity.entity_id as product_id,
				 " . $table_prefix . "catalog_product_entity.sku,
				 " . $table_prefix . "catalog_product_entity_varchar.value as name, 
				 " . $table_prefix . "catalog_product_entity.type_id as type,
				 " . $table_prefix . "catalog_product_entity.has_options,
				 " . $table_prefix . "catalog_product_entity.required_options,
	                        if(  " . $table_prefix . "catalog_product_option.product_id > 0, 'yes', 'no') as ldt_has_custom_options
			from  " . $table_prefix . "catalog_product_entity 
				left join  " . $table_prefix . "catalog_product_entity_varchar 
					on  " . $table_prefix . "catalog_product_entity.entity_id =  " . $table_prefix . "catalog_product_entity_varchar.entity_id 
                                left join  " . $table_prefix . "catalog_product_option
                                        on  " . $table_prefix . "catalog_product_entity.entity_id  =  " . $table_prefix . "catalog_product_option.product_id
		        where  " . $table_prefix . "catalog_product_entity.entity_id BETWEEN " . $incoming_Product_ID . " AND " . $end .
                " and  " . $table_prefix . "catalog_product_entity_varchar.attribute_id = " . $attribute_id .
                " order by  " . $table_prefix . "catalog_product_entity.entity_id ;";

        $_getData = Mage::getSingleton('core/resource')->getConnection('core_read')->fetchAll($_sql);

        return $_getData;
    }

    /*
      {
      $max_id_array = $this->lbsGetMaxProductID();

      foreach ($max_id_array as $one_value ) {
      foreach ( $one_value as $two_value ) {
      };
      };
      $max_id = $two_value;

      $all_skus = "";
      $sku_array = "";

      for ($i=$incoming_Product_ID ; $i<$incoming_Product_ID + $quantity_to_receive ; $i++)
      {
      // Exit loop if we exceed max product ID
      if ( $i > $max_id ) {
      break;
      }

      $product_is_deleted = "false";
      $return_product = "false";

      $sku_array = array
      (
      "product_id"	=> "Does Not Exist"	,
      "incoming_id"	=> $i
      );

      $product = Mage::getModel('catalog/product')->load( $i );  //load the product

      $one_is_deleted	= $product->isDeleted();		// Deleted status
      $one_sku	= $product->getSKU();			// get SKU
      $one_name	= $product->getName();			// get name
      $one_type 	= $product->getTypeID();		// get product type
      $one_productID	= $product->getIdBySku($one_sku);	// get product ID

      $product_is_deleted = $product->isDeleted();

      if ( $one_sku == '' ) {
      $product_is_deleted = "true";
      }
      else{
      $product_is_deleted = "false";
      }

      // Store info about one SKU in an array

      // We check if we are returning deleted products or not.


      if ( $return_deleted == "true" ) {
      $return_product = "true";
      }else{
      if ( $product_is_deleted == "true") {
      $return_product = "false";
      }
      else{
      $return_product = "true";
      }
      }

      $sku_array = array
      (
      "Deleted"	=> $one_is_deleted	,
      "product_id"	=> $one_productID	,
      "sku"		=> $one_sku		,
      "name"		=> $one_name		,
      "type"		=> $one_type		,
      "loop_id"	=> $i
      );

      // Add SKU info to output array
      if ( $return_product == "true" ) {
      $all_skus[ $i ] = $sku_array;
      }else{
      }
      }
      return $all_skus;
      }
     */
    /*
      ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
      '
      '   Description -   lbsGetPartialProductList() - Export selected properties of all products
      '
      ' Amendment Log
      '------------------------------------------------------------------------------------------
      ' Date     | Name            | Vers.     | Description
      '------------------------------------------------------------------------------------------
      ' 21/12/11 | LJG             | 1.02      | Added ldtGetPartialProductList() function
      ' 21/09/13 | TJS             | 1.09      | Changed function name prefix from ldt to lbs
      '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
     */

    public function lbsGetPartialProductList() {

        $all_skus = array();
        $sku_array = array();
        $collection = Mage::getModel('catalog/product')->getCollection();

        $collection->addAttributeToFilter('entity_id', array('in' => array(24, 33)));

        foreach ($collection as $product) {
            // Pull out the most relevant items for each related SKU

            $one_is_deleted = $product->isDeleted();  // Deleted status
            $one_sku = $product->getSKU();   // get SKU
            $one_name = $product->getName();   // get name
            $one_type = $product->getTypeID();  // get product type
            $one_productID = $product->getIdBySku($one_sku); // get product ID
            // Store info about one SKU in an array
            $sku_array = array
                (
                "product_id" => $one_productID,
                "Deleted" => $one_is_deleted,
                "sku" => $one_sku,
                "name" => $one_name,
                "type" => $one_type
            );

            // Add SKU to output array
            $all_skus[$one_productID] = $sku_array;
        };


        return $all_skus;
    }

    /*
      ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
      '
      '   Description -   lbsGetMaxProductID() - Returns highest product ID in use
      '
      ' Amendment Log
      '------------------------------------------------------------------------------------------
      ' Date     | Name            | Vers.     | Description
      '------------------------------------------------------------------------------------------
      ' 21/12/11 | LJG             | 1.03      | Added ldtGetMaxProductID() function
      ' 14/08/12 | LJG             | 1.08      | Modified SQL statements to use lbsGetTablePrefix()
      ' 21/09/13 | TJS             | 1.09      | Changed function name prefix from ldt to lbs
      '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
     */

    public function lbsGetMaxProductID() {
        $table_prefix = $this->lbsGetTablePrefix();

        $_sql = "select max(entity_id) from " . $table_prefix . "catalog_product_entity;";
        $_getData = Mage::getSingleton('core/resource')->getConnection('core_read')->fetchAll($_sql);

        return $_getData;
    }

    /*
      ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
      '
      '   Description -   lbsOrdersUpdatedAfter() - Returns list of orders modified after a given datetime
      '
      ' Amendment Log
      '------------------------------------------------------------------------------------------
      ' Date     | Name            | Vers.     | Description
      '------------------------------------------------------------------------------------------
      ' 09/01/12 | LJG             | 1.00      | Original release
      ' 14/08/12 | LJG             | 1.08      | Modified SQL statements to use lbsGetTablePrefix()
      ' 21/09/13 | TJS             | 1.09      | Changed function name prefix from ldt to lbs
      '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
     */

    public function lbsOrdersUpdatedAfter($sDateTime) {
        $table_prefix = $this->lbsGetTablePrefix();
        $_sql = "select increment_id,original_increment_id,relation_parent_real_id, updated_at from " . $table_prefix . "sales_flat_order where updated_at >= '" . $sDateTime . "' ;";

        $_getData = Mage::getSingleton('core/resource')->getConnection('core_read')->fetchAll($_sql);
        return $_getData;
    }

    /*
      ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
      '
      '   Description -   lbsGetOneProductAttributes() - Returns list of attrbutes for a product ID and attribute set
      '
      ' Amendment Log
      '------------------------------------------------------------------------------------------
      ' Date     | Name            | Vers.     | Description
      '------------------------------------------------------------------------------------------
      ' 29/05/12 | LJG             | 1.07      | Added ldtGetOneProductAttributes()
      ' 14/08/12 | LJG             | 1.08      | Modified SQL statements to use lbsGetTablePrefix()
      ' 21/09/13 | TJS             | 1.09      | Changed function name prefix from ldt to lbs
      '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
     */

    public function lbsGetOneProductAttributes($product_id, $attribute_set_id) {
        $table_prefix = $this->lbsGetTablePrefix();

        $_sql = "SELECT " . $table_prefix . "catalog_product_super_attribute.product_super_attribute_id,
				" . $table_prefix . "catalog_product_super_attribute.product_id,
				" . $table_prefix . "catalog_product_super_attribute.attribute_id,
				position,
				attribute_code,
				attribute_model,
				backend_model,
				backend_type,
				backend_table,
				frontend_model,
				frontend_input,
				frontend_label,
				frontend_class,
				source_model,
				is_required,
				is_user_defined,
				default_value,
				is_unique,
				note,
				entity_attribute_id,
				" . $table_prefix . "eav_entity_attribute.entity_type_id,
				attribute_set_id,
				attribute_group_id,
				sort_order
				FROM " . $table_prefix . "catalog_product_super_attribute
				left join " . $table_prefix . "eav_attribute on " . $table_prefix . "eav_attribute.attribute_id = " . $table_prefix . "catalog_product_super_attribute.attribute_id
				left join " . $table_prefix . "eav_entity_attribute on " . $table_prefix . "eav_entity_attribute.attribute_id = " . $table_prefix . "catalog_product_super_attribute.attribute_id
				where product_id = " . $product_id . " and attribute_set_id = " . $attribute_set_id;

        $_getData = Mage::getSingleton('core/resource')->getConnection('core_read')->fetchAll($_sql);
        return $_getData;
    }
    
    /*
      ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
      '
      '   Description -   lbsCatalogProductAttributeList() - Similar to standard Magento catalogProductAttributeList 
      '                   but returns all attributes (across all sets). Adds an additional date/time parameter to 
      '                   return only those attributes that have been modified after this date/time.
      '                   @param $datetime string 
      '                   @return array $attributes
      '
      ' Amendment Log
      '------------------------------------------------------------------------------------------
      ' Date     | Name            | Vers.     | Description
      '------------------------------------------------------------------------------------------
      ' 20/10/13 | TJS/Aydus       | 1.10      | Function added by davidt@aydus.com and amended by TJS to include table prefix
      ' 01/11/13 | Aydus           | 1.11      | Modified to return attributes not part of an atribute set
      '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
     */
    public function lbsCatalogProductAttributeList($datetime = NULL){
    	
    	$read = Mage::getSingleton('core/resource')->getConnection('core_read');
    	$attributes = array();
    	
    	//get entity type id for catalog_product
    	$entityType = Mage::getModel('eav/config')->getEntityType('catalog_product');
    	$entityTypeId = $entityType->getEntityTypeId();
    	 
    	//get all product attributes
		$attributeCollection = Mage::getResourceModel('eav/entity_attribute_collection');
		$attributeCollection->addFieldToFilter('entity_type_id', $entityTypeId);
		$select = $attributeCollection->getSelect();
		$select->join(array(
			'join_table'=> Mage::getConfig()->getTablePrefix().'catalog_eav_attribute'), 
			'main_table.attribute_id = join_table.attribute_id', 
			array('join_table.is_global')
		);
		
		//datetime filter
		if (strtotime($datetime)){
			//strip out the time from filter, we just want to select all attributes
			//modified inclusive of the date and not deal with hours-minutes-seconds
			$date = date("Y-m-d", strtotime($datetime));
			$select->join(array(
				'log_table'=> Mage::getConfig()->getTablePrefix().'lerryn_lbsapi_attributesave_log'), 
				"log_table.attribute_id = join_table.attribute_id AND log_table.attribute_modification_date >= '$date' ", 
				array('log_table.attribute_modification_date')
			);
			$attributeCollection->addOrder("log_table.attribute_modification_date");
		}else {
			
			$attributeCollection->addOrder("attribute_id");
		}
				
		//loop each attribute in the collection
        foreach ($attributeCollection as $attribute) {

        	//http://www.solvingmagento.com/magento-eav-system/
            switch ($attribute->getIsGlobal()){
            	case 1 :	//global
            		$scope = 'global';
            		break;
            	case 2 : //website
            		$scope = 'website';
            		break;
            	case 0 : default :	//store view
                	$scope = 'store';
            		break;
            }
            $attributeAr = array(
            	'attribute_id' => $attribute->getId(),
            	'code' => $attribute->getAttributeCode(),
            	'type' => $attribute->getFrontendInput(),
            	'required' => $attribute->getIsRequired(),
            	'scope' => $scope,
            );
            
            //add attribute modification date to result
            if ($attribute->getAttributeModificationDate()){
            	$attributeAr['attribute_modification_date'] = $attribute->getAttributeModificationDate();
            }
                        
            //add attribute to return array
            $attributes[] = $attributeAr;            
        }    	
    	
        return $attributes;
    }
    
    /*
      ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
      '
      '   Description -   lbsCatalogProductAttributeInfoList() - Similar to standard Magento catalogProductAttributeInfo 
      '                   but returns all attributes. Adds an additional date/time parameter to 
      '                   return only those attributes that have been modified after this date/time.
      '                   @param $datetime string 
      '                   @return array $infos
      '
      ' Amendment Log
      '------------------------------------------------------------------------------------------
      ' Date     | Name            | Vers.     | Description
      '------------------------------------------------------------------------------------------
      ' 20/10/13 | TJS/Aydus       | 1.10      | Function added by davidt@aydus.com
      '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
     */
    public function lbsCatalogProductAttributeInfoList($datetime = NULL){
    	 
    	//get attributes list
		$attributes = $this->lbsCatalogProductAttributeList($datetime);
		$infos = array();
		
		//get loaded attributes
		if (is_array($attributes) && count($attributes)>0){
			foreach ($attributes as $attribute){
				$attributeId = $attribute['attribute_id'];
				$info = Mage::getModel("catalog/product_attribute_api")->info($attributeId);
				//add attribute modification date
				if ($datetime){
					$info['attribute_modification_date'] = $attribute['attribute_modification_date'];
				}
				$infos[] = $info;
			}
		}
    	 
    	return $infos;
    }    
    
    /*
      ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
      '
      '   Description -   lbsAssignSimplesToConfigurable() - associate simple products with their parent configurable product 
      '                   Ideally, all simple products can be assigned to one parent in one api call 
      '                   
      '                   @param int $id The parent configurable

      '                   @param int array $ids Array of simple product ids

      '                   @return array Array of simple product ids that were assigned

      '
      ' Amendment Log
      '------------------------------------------------------------------------------------------
      ' Date     | Name            | Vers.     | Description
      '------------------------------------------------------------------------------------------
      ' 01/11/13 | TJS/Aydus       | 1.11      | Function added by davidt@aydus.com
      '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
     */

    public function lbsAssignSimplesToConfigurable($parentId, $ids){

    	try {

   
    		$configurable = Mage::getModel("catalog/product")->load($parentId);

   
    		if ($configurable->getTypeId()!="configurable"){

    			throw new Exception("Parent type must be configurable not ".$configurable->getTypeId());

    		}

   
    		$productIds = array();
   
    		foreach ($ids as $id){
   
    			$simple = Mage::getModel("catalog/product")->load($id);

 
    			if ((int)$simple->getAttributeSetId() === (int)$configurable->getAttributeSetId()){

    				$productIds[] = $id;

    			}

    		}

   
    		Mage::getResourceModel('catalog/product_type_configurable')->saveProducts($configurable, $productIds);

   
    		return $productIds;

   
    	}
    	catch (Exception $e){

   
    		throw new SoapFault("LBSapi", $e->getMessage());

    	}

    }    
    
    /*
      ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
      '
      '   Description -   lbsGetAttributeTimestamp() - Returns the latest timestamp in the 
      '                   lerryn_lbsapi_attributesave_log table
      '
      ' Amendment Log
      '------------------------------------------------------------------------------------------
      ' Date     | Name            | Vers.     | Description
      '------------------------------------------------------------------------------------------
      ' 20/10/13 | TJS             | 1.10      | Function added 
      ' 01/11/13 | TJS             | 1.11      | Modified to return current time if table empty
      '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
     */

    public function lbsGetAttributeTimestamp() {
        $table_prefix = $this->lbsGetTablePrefix();

        $_sql = "select IFNULL(max(attribute_modification_date), now()) AS LastModified from " . $table_prefix . "lerryn_lbsapi_attributesave_log;";
        $_getData = Mage::getSingleton('core/resource')->getConnection('core_read')->fetchAll($_sql);

        return $_getData;
    }

    /*
      ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
      '
      '   Description -   lbsGetTablePrefix() - Returns database table prefix
      '
      ' Amendment Log
      '------------------------------------------------------------------------------------------
      ' Date     | Name            | Vers.     | Description
      '------------------------------------------------------------------------------------------
      ' 14/08/12 | LJG             | 1.08      | Original release
      ' 21/09/13 | TJS             | 1.09      | Changed function name prefix from ldt to lbs
      '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
     */

    public function lbsGetTablePrefix() {

        $prefix = Mage::getConfig()->getTablePrefix();
        return $prefix;
    }
    

}

//$this->ldtWriteToFile( "Lloyd", "Product is deleted " . $i . " " . $product_is_deleted );
//$this->ldtWriteToFile( "Lloyd", "Return Product " . $i . " " . $return_product);
?>
