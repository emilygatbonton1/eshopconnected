<?php
 


//

// eShopCONNECT - Magento API

// Module: Observer.php

//

// This software is the copyright of Lerryn Business Solutions Ltd and

// may not be copied, duplicated or modified other than as permitted

// in the licence agreement.

//

//       � 2012 - 2013  Lerryn Buniness Solutions Ltd

//                      2 East View

//                      Bessie Lane

//                      Bradwell

//                      Hope Valley

//                      S33 9HZ

//

// Tel +44 (0)1433 621584

// Email Support@lerryn.com

//

// Lerryn is a Trademark of Lerryn Business Solutions Ltd

// eShopCONNECT is a Trademark of Lerryn Business Solutions Ltd

// -------------------------------------------------------------------




class Lerryn_LBSapi_Model_Observer {


    /*
      ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

      '
      '   Description -   API Observer - creates/updates records in lerryn_lbsapi_attributesave_log
 
      '                                  table for attribute save
      
'
      '                   @param Mage_Core_Model_Observer $observer

      '
      ' Amendment Log

      '------------------------------------------------------------------------------------------

      ' Date     | Name            | Vers.     | Description

      '------------------------------------------------------------------------------------------

      ' 28/10/13 | TJS/Aydus       | 1.10      | Function added by davidt@aydus.com and amended by TJS to include table prefix

      '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
     */

    public function saveAttributeModificationDate($observer){

	$read = Mage::getSingleton('core/resource')->getConnection('core_read');

	$write = Mage::getSingleton('core/resource')->getConnection('core_write');


	$attribute = $observer->getAttribute();

	$attributeId = $attribute->getId();

	$counted = $read->fetchOne("SELECT COUNT(*) AS counted FROM " . Mage::getConfig()->getTablePrefix() . "lerryn_lbsapi_attributesave_log WHERE attribute_id = '$attributeId'");

	if ($counted){

		$sql = "UPDATE " . Mage::getConfig()->getTablePrefix() . "lerryn_lbsapi_attributesave_log SET attribute_modification_date = NOW() WHERE attribute_id = '$attributeId'";

	}else {

		$sql = "INSERT INTO " . Mage::getConfig()->getTablePrefix() . "lerryn_lbsapi_attributesave_log (attribute_id, attribute_modification_date) VALUES('$attributeId', NOW())";

		}

	$write->query($sql);

	}


}